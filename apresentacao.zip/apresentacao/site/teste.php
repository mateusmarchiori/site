<?php

session_start(); //comando para utilizar sessão, stater

if(isset($_REQUEST['entrar'])){
	

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "acesso";

$login = $_POST['login'];
$senha = MD5($_POST['senha']);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


 $sql = "SELECT * FROM LOGIN WHERE LOGIN = '$login' AND SENHA = '$senha'";

$query = mysqli_query($conn,$sql) or die (mysqli_error());
$qtda = mysqli_num_rows($query);

if ($qtda == 0){
	echo 'Erro ao logar , Favor entrar em contato com adminstrador do sistema !!!';
}else{
	header("location: home.html");
}

}

mysqli_close($conn);
 
?>