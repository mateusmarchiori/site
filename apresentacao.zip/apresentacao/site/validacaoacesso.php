<?php
    session_start(); //comando para utilizar sessão, stater

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "acesso";



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

		 
        $dados['login'] = $_POST['login'];
        $dados['senha'] = md5($_POST['senha']);
       
        $sql = "SELECT login FROM login WHERE login=:login AND senha=:senha";
        $registro = $conn->getRegistro($sql, $dados);
        if($registro == NULL) echo "Não achou";
        else{
          $_SESSION['autenticado']=$registro['login'];
          header('location: home.html');
        }
    
?>