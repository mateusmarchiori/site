


<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "projeto01";

$inputnome = $_POST['inputnome'];
$inputprofissao = $_POST['inputprofissao'];
$inputendereco = $_POST['inputendereco'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$inputCity = $_POST['inputCity'];
$inputestado = $_POST['inputestado'];
$inputdata = $_POST['inputdata'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO pessoa (nome , profissao , endereco,email , senha , cidade , estado , datanasc) 
VALUES ('$inputnome' , '$inputprofissao','$inputendereco','$email' , '$senha' , '$inputCity',
'$inputestado' , '$inputdata')";

if ($conn->query($sql) === TRUE) {
    echo "Cadastro realizado com sucesso";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
